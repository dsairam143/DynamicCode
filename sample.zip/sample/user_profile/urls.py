from django.urls import path
from . import views


urlpatterns = [
    path('user-signup', views.user_signup, name='signup'),
    path('user-signin', views.user_login, name='login'),
    path('validate-mail/', views.mail_validation, name='mailvalidate'),
    path('home/', views.home, name='home'),
    path('logout/', views.user_logout, name='logout'),
    path('forget-password/', views.forget_password, name='forget_password'),
    path('reset-password/', views.reset_password, name='reset_password'),
]