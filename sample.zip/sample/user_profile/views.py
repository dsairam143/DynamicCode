from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Users, MailValidation, restpassword
from passlib.hash import sha256_crypt
from django.contrib.auth.tokens import default_token_generator
from .custom_gmail import gmail_authenticate,send_message
import re
import uuid

domain = 'http://127.0.0.1:8000'

def sendgmail(mail, token):
    try:


        to_mail = mail
        subject = 'Mail Verification'

        message = """
                Please click the below link to verify your mail id.
                {domain}/user/validate-mail/?mid={to_mail}&token={token}        
        """.format(to_mail=to_mail, token=token, domain=domain)

        service = gmail_authenticate()
        # test send email
        send_message(service, to_mail, subject,
                     message, [])
    except Exception as e:
        print(e)

# Validate user details
def validate_user_details(request):
    user_validation = dict()
    try:
        user = request.POST['user_name']
        if user:
            if len(user)<5:
                user_validation['user_name'] = 'Minimum 5 characters required for user registration.'
    except:
        pass

    try:
        email = request.POST['email']
        if email:
            print(email)
            if not all([True if k in email else False for k in ['@', '.']]):
                user_validation['email'] = 'Please enter valid mail id'
    except:
        pass

    try:
        password = request.POST['password']
        if len(password)<7:
            user_validation['password'] = 'Minimum 6 characters required.'
    except:
        pass

    try:
        phone = request.POST['phone']
        if len(phone)<10:
            user_validation['phone'] = 'Please enter valid phone number'
        if re.search('[^0-9-]', phone):
            user_validation['phone'] = 'Only Digits(0-9 -) are allowed.'
    except:
        pass

    try:
        user = Users.objects.filter(email=email)
        if user:
            user_validation['email'] = 'This user already registered in our database. Please try with new mail account.'
    except:
        pass

    return user_validation


def user_signup(request):
   if request.method == 'POST':
          vud = validate_user_details(request)
          if validate_user_details(request):
                return render(request, 'user/signup.html', {'user_validation': vud})

          user_name = request.POST.get('user_name')
          email = request.POST.get('email')
          password = request.POST.get('password')
          password = sha256_crypt.encrypt(password)
          phone = request.POST.get('phone')
          org = request.POST.get('org')
          Users(user_name=user_name, email=email, password=password, phone=phone, org=org).save()
          user = Users.objects.get(email=email)
          token = uuid.uuid4().hex
          print(token)
          # token = default_token_generator.make_token(token)
          MailValidation(user_id=user.id, user_mail=user.email, user_name=user.user_name, key=token).save()
          print('Token Saved')
          sendgmail(email, token)
          return render(request, 'user/mail_verification_message.html', {'mail': email})
   return render(request, 'user/signup.html', {})



def user_login(request):
    if request.method == 'POST':
        try:
            email = request.POST['email']
            password = request.POST['password']
            user = Users.objects.get(email=email)

            if not sha256_crypt.verify(password, user.password):
                return render(request, 'user/signin.html', {
                    'signin_status': '<p style="text-align:center; color:red">Please enter correct credentials.<p>'})
            if user.valid_mail == 0:
                return render(request, 'user/verification_message.html')


            request.session['user'] = user.user_name
            request.session['email'] = user.email
            request.session['id'] = user.id
            request.session['phone'] = user.phone

            return redirect('home')

        except (Users.DoesNotExist, ValueError) as e:
            return render(request, 'user/signin.html', {
                'signin_status': '<p style="text-align:center; color:red">Please enter correct credentials.<p>'})

    return render(request, 'user/signin.html')


def mail_validation(request):
    token = request.GET['token']
    mid = request.GET['mid']
    try:
        mv = MailValidation.objects.get(user_mail=mid, key=token)
        user = Users.objects.get(email=mid)
        user.valid_mail = 1
        user.save()
        mv.delete()
        return render(request, 'user/mail-validation-succes-message.html')
    except:
        return render(request, 'user/mail-validation-failed-message.html')


def home(request):
    if request.session.has_key('user'):
        return render(request, 'home.html')
    else:
        return redirect('login')

def user_logout(request):
    request.session.flush()
    return redirect('home')


def reset_password(request):
    print(request.method)
    if request.method == 'GET':
        mid = request.GET['mid']
        token = request.GET['token']
        try:
            rp = restpassword.objects.filter(user_mail=mid, key=token)
            if rp:
                return render(request, 'user/password-reset.html', {'token':token, 'mid':mid})
            else:
                return HttpResponse('Please contact admin')
        except Exception as e:
            return HttpResponse(str(e))
    elif request.method == 'POST':
        mid = request.POST['mid']
        token = request.POST['token']
        password = request.POST['password']
        cpassword = request.POST['cpassword']

        if len(password)<6:
           return render(request, 'user/password-reset.html', {'token':token, 'mid':mid, 'message': 'Password should be more than 6 characters.'})

        if password != cpassword:
            return render(request, 'user/password-reset.html',
                          {'token': token, 'mid': mid, 'message': 'Password and confirm password must be same.'})

        password = sha256_crypt.encrypt(password)
        # Password validation code

        rps = restpassword.objects.filter(user_mail=mid, key=token)
        if rps:
            rp = rps[0]
        user = Users.objects.get(id=rp.user_id)
        user.password = password
        user.save()
        for rp in rps:
            rp.delete()

        return redirect('login')


def reset_password_gmail(mail, token):

    try:
        to_mail = mail
        subject = 'Mail Verification'

        message = """
                        Please click the below link to reset your password.
                        {domain}/user/reset-password/?mid={to_mail}&token={token}        
                """.format(to_mail=to_mail, token=token, domain=domain)

        service = gmail_authenticate()
        # test send email
        send_message(service, to_mail, subject,
                     message, [])
    except:
        pass


def forget_password(request):
    if request.method == 'POST':
        try:
            mail= request.POST['mail']
            user = Users.objects.get(email=mail)
            token = uuid.uuid4().hex

            restpassword(user_id=user.id, user_mail=user.email, user_name=user.user_name, key=token).save()
            reset_password_gmail(mail, token)

            return HttpResponse('We have sent a password reset link to your registered mail id.')
        except Exception as e:
            print(e)
            return HttpResponse('Your mail doesn\'t exists in our database.')
    return render(request, 'user/forgot-password-html.html')
