from django.contrib import admin

# Register your models here.
from .models import Users, MailValidation

class UsersAdmin(admin.ModelAdmin):
    list_display = ['id', 'user_name', 'email', 'phone', 'org', 'last_login', 'valid_mail']

admin.site.register(Users, UsersAdmin)


class MailAdmin(admin.ModelAdmin):
    list_display = ['id', 'user_id', 'user_mail', 'user_name', 'key']

admin.site.register(MailValidation, MailAdmin)