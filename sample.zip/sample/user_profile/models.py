from django.db import models

from datetime import datetime
today = datetime.now()


# Create your models here.
class Users(models.Model):
    user_name = models.CharField(max_length=150)
    email = models.CharField(max_length=100)
    password = models.CharField(max_length=200)
    phone = models.CharField(max_length=20)
    org = models.CharField(max_length=20)
    last_login = models.DateTimeField(default=today)
    valid_mail = models.IntegerField(default=0)


class MailValidation(models.Model):
    user_id = models.IntegerField(default=0)
    user_mail = models.EmailField(max_length=100)
    user_name = models.CharField(max_length=100)
    key = models.TextField()
    class Meta:
        db_table = 'mail_validation'


class restpassword(models.Model):
    user_id = models.IntegerField(default=0)
    user_mail = models.EmailField(max_length=100)
    user_name = models.CharField(max_length=100)
    key = models.TextField()
    class Meta:
        db_table = 'password_reset'