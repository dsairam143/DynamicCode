from django.contrib import admin
from django.http import HttpResponse
from django.urls import path

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
import requests as rs
from .models import SearchAPI
import json
# my dummy model

@login_required
def my_custom_view(request):
    if request.method=='POST':
        api = request.POST.get('q', None)
        resp = rs.get(api)
        data = resp.json()
        # data = json.dumps(data, indent=3)
        return render(request, "admin_template.html", {'data':data})
    return render(request, "admin_template.html", {})


class DummyModelAdmin(admin.ModelAdmin):
    model = SearchAPI

    def get_urls(self):
        view_name = '{}_{}_changelist'.format(
            self.model._meta.app_label, self.model._meta.model_name)
        return [
            path('search-api/', my_custom_view, name=view_name),
        ]
admin.site.register(SearchAPI, DummyModelAdmin)
admin.autodiscover()