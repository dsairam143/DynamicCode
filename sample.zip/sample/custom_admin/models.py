from django.db import models

# Create your models here.
class SearchAPI(models.Model):

    class Meta:
        verbose_name_plural = 'Search API'
        app_label = 'custom_admin'