from selenium import webdriver
from bs4 import BeautifulSoup
import time
import re
import pandas as pd
md = pd.read_excel('missedDomainList.xlsx')
md = md.to_dict('records')
domainsList = []
driver = webdriver.Chrome()
driver.maximize_window()
for comp in md:
    try:
        companyName = comp['companyName']

        driver.get('https://www.otcmarkets.com/')
        driver.find_element_by_xpath('//*[@id="root"]/div/div[2]/div[1]/div[1]/div/div[1]/input').clear()
        driver.find_element_by_xpath('//*[@id="root"]/div/div[2]/div[1]/div[1]/div/div[1]/input').send_keys(companyName.replace(' INC',''))
        time.sleep(5)
        driver.find_element_by_xpath('//*[@id="root"]/div/div[2]/div[1]/div[1]/div/div[2]/div/div[2]').click()
        time.sleep(5)
        jsoup = BeautifulSoup(driver.page_source, 'html.parser')
        h2 = jsoup.find('h2')
        p = h2.parent.find('p').text
        print(p)
        driver.get('https://www.otcmarkets.com/stock/'+h2.text+'/profile')
        time.sleep(5)
        jsoup = BeautifulSoup(driver.page_source, 'html.parser')
        text = '\n'.join([a.text for a in jsoup.find_all('a')])
        domains = re.findall('www\S+|http\S+', text, re.IGNORECASE)
        foundDomainInner = False
        splitcompany = [c for c in companyName.split() if len(c)>=3]
        if not splitcompany:
            continue
        splitcompany = splitcompany[0]
        found = False
        print(domains)
        for domain in domains:
            if splitcompany.lower() in domain.lower():
                print(domain)
                domainsList.append([comp['companyName'],p, domain])
                found = True
        if not found:
            domainsList.append([comp['companyName'], p, None])

    except:
        pass
df = pd.DataFrame(domainsList, columns=['companyName','dupComp', 'Domain'])
df.to_excel('DomainsSecondCheck.xlsx', index=False)