import pandas as pd
import requests
import re
from bs4 import BeautifulSoup
import pandas as pd
from urllib.parse import urlparse
from urllib.parse import urlsplit
# df = pd.read_excel('CommonStockData.xlsx')
#Data Input From sec address raw data
df = pd.read_excel('rawData-01-03-2019.xlsx')
df = df.drop_duplicates(subset=['mainUrl'])
print(len(df))
urls = df.to_dict('records')
print(urls)
domainList = []
for url in urls:
    print('==================================================')
    print('Company Name = ', url['companyName'])
    print(url['mainUrl'])
    companyName = url['companyName']
    companyName = [c for c in companyName.split() if len(c)>=3]
    if not companyName:
        continue
    companyName = companyName[0]
    resp = requests.get(url['mainUrl'])
    jsoup = BeautifulSoup(resp.content, 'html.parser')
    table = jsoup.find('table', attrs={'class':'tableFile2'})
    anchors = table.find_all('tr')
    companyDomain = False
    for a in anchors:
        try:
            _url = 'https://www.sec.gov'+a.find('a')['href']
            # print(_url)

            resp = requests.get(_url)
            jsoup = BeautifulSoup(resp.content, 'html.parser')

            innerTable = jsoup.find('table', attrs={'class': 'tableFile'})
            trs = innerTable.find_all('tr')
            foundDomain = False
            for tr in trs[::-1]:
                try:
                    innerUrl = 'https://www.sec.gov'+tr.find('a')['href']
                    domainData = requests.get(innerUrl)
                    djsoup = BeautifulSoup(domainData.content, 'html.parser')
                    domainText = djsoup.text
                    domain = re.findall('www\S+|http\S+', domainText, re.IGNORECASE)
                    foundDomainInner = False
                    if domain:
                        for d in domain:
                            # print(companyName, domain, innerUrl)
                            if companyName.lower() in d.lower():
                                print(companyName, domain, innerUrl)
                                domainName = d

                                foundDomain = True
                                foundDomainInner = True
                                companyDomain = True
                                url['Domain'] = domainName
                                domainList.append(url)
                                print(domainName)
                                break
                    if foundDomainInner:
                        break

                    # break
                except Exception as e:

                    pass
            if foundDomain:
                break
        except:
            pass

    if not companyDomain:
        url['Domain'] = None
        domainList.append(url)

df = pd.DataFrame(domainList)
df.to_excel('Domains.xlsx', index=False)


#====================================Domain Filter=============================================
df = df = pd.read_excel('Domains.xlsx')
def filterDomain(x):
    if  isinstance(x, str):
        if '.com' in x.lower():
            return x[:x.lower().index('.com')+4]
        else:
            return x
    else:
        return x

df['Domain'] = df['Domain'].apply(filterDomain)
order = ['companyName', 'Domain', 'mainUrl']
df = df[order]
df.to_excel('DomainsData.xlsx', index=False)

#===============================Check Missed Domain ================================================
dm = df = pd.read_excel('DomainsData.xlsx')
headers = dm.columns.tolist()
dm = dm.values.tolist()

totalComp = df = pd.read_excel('List of Sample 100 companies.xlsx')
totalComp = totalComp.values.tolist()
missedDomains = []
for comp in totalComp:
    # print(comp)
    found = False
    for d in dm:
        if comp[0] in d:
            found = True
            if not isinstance(d[1], str):
                missedDomains.append(d)

                break
    if not found:
        missedDomains.append([comp[0],None, None])

df = pd.DataFrame(missedDomains, columns=headers)
df.to_excel('missedDomainList.xlsx', index=False)
