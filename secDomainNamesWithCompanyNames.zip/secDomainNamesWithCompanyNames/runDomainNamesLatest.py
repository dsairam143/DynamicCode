import pandas as pd
import requests
import re
from bs4 import BeautifulSoup
from Check import SecondChec
import datetime
import os

today = datetime.datetime.today().strftime('%m-%d-%Y')
if not os.path.exists(today):
    os.makedirs(today)


def tableDataExtractor(jsoup):
    if jsoup.find('table'):
        print('found')
        table = jsoup.find('table')

        trs = table.find_all('tr')
        nooftd = 0
        for tr in trs:
            tds = tr.find_all(re.compile('th|td'))
            if len(tds) > nooftd:
                nooftd = len(tds)
        trList = []
        for tr in trs:
            tds = tr.find_all(re.compile('th|td'))
            tdList = []
            for td in tds:
                colspan = 0
                try:
                    colspan = int(td['colspan'])
                except:
                    pass
                if colspan != 0:
                    tdList.append(td.text)
                    for k in range(colspan - 1):
                        tdList.append('')
                else:
                    link = td.find('a')['href'] if td.find('a') else None
                    tdList.append([td.text, link])

            trList.append(tdList)
        return trList



headers = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36"}
# df = pd.read_excel('filteredCompanies.xlsx')
df = pd.read_excel('List of Sample 100 companies.xlsx')
companies = df.values.tolist()
print(companies)
finalResultData = []
failedList = []
compniesWithCIK = []
for com in companies:
    print('='.center(100, '='))
    print('|'.center(100, '|'))
    print('='.center(100, '='))
    # url = 'https://www.sec.gov/cgi-bin/browse-edgar?CIK='+str(com[2])
    url = 'https://www.sec.gov/cgi-bin/browse-edgar?company='+str(com[0]).replace('&', '%26').replace(' ', '+')+'&owner=exclude&action=getcompany'
    print(url)

    jsoup = BeautifulSoup(requests.get(url, headers=headers).content)
    companyName = jsoup.find('span', attrs={'class':'companyName'})
    companyName = companyName.text if companyName else companyName
    table = jsoup.find('div', attrs={'id':'seriesDiv'})

    if not companyName:
        secondData = SecondChec(com[0])
        if not secondData['companyName']:
            failedList.append([com[0], 'Not Found'])
            continue

        else:
            companyName = secondData['companyName']
            table = secondData['table']
            url = secondData['url']

    companyName = re.search('(.*)CIK[^\d]*([0-9]+).*', companyName)
    company_Name = companyName.group(1)
    CIK = companyName.group(2)
    compniesWithCIK.append([com[0],company_Name, CIK])
    # print(table)
    tableData =tableDataExtractor(table)


    # break
    filterList = []

    for i in ['8-K', '10-K', '10-Q', '20F']:
        for k in tableData:
            if i in k[0]:
                filterList.append(k)
                # print(k[0])
                break
    print(filterList)
    # break
    if not filterList:
        failedList.append([com[0], "Found But No Data"])
    for fl in filterList:
        filteredUrl = 'https://www.sec.gov' + fl[1][1]
        print('Main Url = ', filteredUrl)
        subTable = BeautifulSoup(requests.get(filteredUrl).content).find('table', attrs={'class':'tableFile'}).parent
        # print(subTable)
        subTableData = tableDataExtractor(subTable)
        print(subTableData)
        for l in subTableData:
        #
            if fl[0][0] in l[1] or fl[0][0] in l[3]:
                print('https://www.sec.gov' + l[2][1])
                dataLink = 'https://www.sec.gov' + l[2][1].replace('ix?doc=/', '')
                resp = requests.get(dataLink).content
                jsoup = BeautifulSoup(resp)
                for k in jsoup.find_all('div', attrs={'style': 'display:none'}):
                    k.decompose()

                # content = jsoup.text

                EDA = extractDateAndAddress(jsoup.text,jsoup)
                print(EDA)
        #
                finalResultData.append(
                    [com[0],company_Name, CIK, fl[0][0], EDA['newdate'], EDA['filteredAddress'], EDA['keyword'],
                     EDA['rawContent'], EDA['country'], dataLink, url, EDA['incorporation'], EDA['domicile']])
                # return
                break
    # break
    # print(url)


df = pd.DataFrame(finalResultData,columns=['companyName','dupName', 'companyId', 'Form', 'PostedDate', 'filteredAddress', 'Keyword','rawContent','country', 'dataLink', 'mainUrl', 'incorporation', 'domicile'])

df.to_excel(today+'\\rawData-'+today+'.xlsx', index=False)

dd = pd.DataFrame(failedList, columns=['CompanyName', 'Status'])
dd.to_excel(today+'\\failedCompaniesList-'+today+'.xlsx', index=False)

ddd = pd.DataFrame(compniesWithCIK, columns=['CompanyName', 'DupName', 'CIK'])
ddd.to_excel('CompaniesWithCIK.xlsx', index=False)

