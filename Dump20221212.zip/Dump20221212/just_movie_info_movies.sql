CREATE DATABASE  IF NOT EXISTS `just_movie_info` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `just_movie_info`;
-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: just_movie_info
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `movies`
--

DROP TABLE IF EXISTS `movies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text,
  `language` text,
  `date` text,
  `movie_id` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movies`
--

LOCK TABLES `movies` WRITE;
/*!40000 ALTER TABLE `movies` DISABLE KEYS */;
INSERT INTO `movies` VALUES (1,'Dabangg 3','Hindi','20th Dec, 2019','Dabangg39412'),(2,'Mardaani 2','Hindi','13th Dec, 2019','Mardaani21609'),(3,'Panipat','Hindi','06th Dec, 2019','Panipat4853'),(4,'Pati Pa...Aur Woh','Hindi','06th Dec, 2019','PatiPaAurWoh2279'),(5,'Sye Raa','Hindi','02nd Oct, 2019','SyeRaa4540'),(6,'The Zoya Factor','Hindi','20th Sep, 2019','TheZoyaFactor6025'),(7,'Prassthanam','Hindi','20th Sep, 2019','Prassthanam8400'),(8,'Chhichhore','Hindi','06th Sep, 2019','Chhichhore135'),(9,'Prati R...andaage','Telugu','20th Dec, 2019','PratiRandaage3125'),(10,'Donga','Telugu','20th Dec, 2019','Donga7762'),(11,'Ruler','Telugu','20th Dec, 2019','Ruler5617'),(12,'Venky Mama','Telugu','13th Dec, 2019','VenkyMama8363'),(13,'Ragala ...antallo','Telugu','22nd Nov, 2019','Ragalaantallo2305'),(14,'George Reddy','Telugu','22nd Nov, 2019','GeorgeReddy1446'),(15,'Tenali ...krishna','Telugu','15th Nov, 2019','Tenalikrishna7865'),(16,'Action','Telugu','15th Nov, 2019','Action773'),(17,'Hero','Tamil','20th Dec, 2019','Hero5482'),(18,'Thambi','Tamil','20th Dec, 2019','Thambi7188'),(19,'Kaithi','Tamil','25th Oct, 2019','Kaithi9142'),(20,'Bigil','Tamil','25th Oct, 2019','Bigil4305'),(21,'Saaho','Tamil','30th Aug, 2019','Saaho4645'),(22,'Nerkond...Paarvai','Tamil','08th Aug, 2019','NerkondPaarvai5437'),(23,'Jackpot','Tamil','02nd Aug, 2019','Jackpot3312'),(24,'Kazhugu 2','Tamil','01st Aug, 2019','Kazhugu24909'),(25,'Saaho','Malayalam','30th Aug, 2019','Saaho1494'),(26,'Lucifer','Malayalam','29th Mar, 2019','Lucifer3398'),(27,'Oru Adaar Love','Malayalam','14th Feb, 2019','OruAdaarLove6028'),(28,'Nine','Malayalam','07th Feb, 2019','Nine155'),(29,'Thattum...chuthan','Malayalam','22nd Dec, 2018','Thattumchuthan1666'),(30,'Ente Um...te Peru','Malayalam','21st Dec, 2018','EnteUmtePeru7323'),(31,'Pretham 2','Malayalam','21st Dec, 2018','Pretham25177'),(32,'Njan Prakashan','Malayalam','21st Dec, 2018','NjanPrakashan1716'),(33,'Saaho','Kannada','30th Aug, 2019','Saaho3354'),(34,'Yajamana','Kannada','01st Mar, 2019','Yajamana1880'),(35,'Natasaa...abhowma','Kannada','07th Feb, 2019','Natasaaabhowma3942'),(36,'Bazaar','Kannada','01st Feb, 2019','Bazaar9919'),(37,'Gultoo','Kannada','30th Mar, 2018','Gultoo9620'),(38,'Edhiga ... Suddhi','Kannada','30th Mar, 2018','EdhigaSuddhi2653'),(39,'Heegondhu Dina','Kannada','30th Mar, 2018','HeegondhuDina554'),(40,'Yogi Duniya','Kannada','23rd Mar, 2018','YogiDuniya1865'),(41,'Khandaa...fakhana','Hindi','02nd Aug, 2019','Khandaafakhana1113'),(42,'Judgeme...Hai Kya','Hindi','26th Jul, 2019','JudgemeHaiKya8258'),(43,'Super 30','Hindi','12th Jul, 2019','Super303041'),(44,'Malaal','Hindi','05th Jul, 2019','Malaal6696'),(45,'PM Nare...ra Modi','Hindi','24th May, 2019','PMNareraModi6701'),(46,'De De Pyaar De','Hindi','17th May, 2019','DeDePyaarDe1873'),(47,'Student... Year 2','Hindi','10th May, 2019','StudentYear26957'),(48,'Kalank','Hindi','19th Apr, 2019','Kalank9461'),(49,'Raju Ga...Gadhi 3','Telugu','18th Oct, 2019','RajuGaGadhi32003'),(50,'RDX Love','Telugu','11th Oct, 2019','RDXLove6343'),(51,'Chanakya','Telugu','05th Oct, 2019','Chanakya2177'),(52,'Sye Raa','Telugu','02nd Oct, 2019','SyeRaa1610'),(53,'Saaho','Telugu','30th Aug, 2019','Saaho5403'),(54,'Kousaly...amurthy','Telugu','23rd Aug, 2019','Kousalyamurthy5176'),(55,'Ranarangam','Telugu','15th Aug, 2019','Ranarangam6125'),(56,'Evaru','Telugu','15th Aug, 2019','Evaru6103'),(57,'Suttu P...tharavu','Tamil','14th Jun, 2019','SuttuPtharavu2881'),(58,'Nenjamu...du Raja','Tamil','14th Jun, 2019','NenjamuduRaja6325'),(59,'Game Over','Tamil','14th Jun, 2019','GameOver1159'),(60,'Kolaigaran','Tamil','07th Jun, 2019','Kolaigaran5750'),(61,'Ayogya','Tamil','11th May, 2019','Ayogya8033'),(62,'K13','Tamil','03rd May, 2019','K135002'),(63,'Vellai Pookal','Tamil','19th Apr, 2019','VellaiPookal932'),(64,'Mehandi Circus','Tamil','19th Apr, 2019','MehandiCircus4335'),(65,'Drama','Malayalam','01st Nov, 2018','Drama1540'),(66,'Dakini','Malayalam','19th Oct, 2018','Dakini9288'),(67,'Kayamku...ochunni','Malayalam','11th Oct, 2018','Kayamkuochunni6199'),(68,'Lilli','Malayalam','28th Sep, 2018','Lilli8153'),(69,'Ranam -...rossing','Malayalam','06th Sep, 2018','Ranamrossing4137'),(70,'Kinavalli','Malayalam','27th Jul, 2018','Kinavalli5837'),(71,'Ente Me...zhangal','Malayalam','27th Jul, 2018','EnteMezhangal9782'),(72,'Maradona','Malayalam','27th Jul, 2018','Maradona8178'),(73,'Rajasimha','Kannada','02nd Feb, 2018','Rajasimha4370'),(74,'Churikatte','Kannada','26th Jan, 2018','Churikatte1764'),(75,'Raju Ka... Medium','Kannada','19th Jan, 2018','RajuKaMedium929'),(76,'Humble ... Nograj','Kannada','12th Jan, 2018','HumbleNograj23'),(77,'Mass Leader','Kannada','11th Aug, 2017','MassLeader3027'),(78,'Raj Vishnu','Kannada','04th Aug, 2017','RajVishnu9289'),(79,'Dandupalya 2','Kannada','14th Jul, 2017','Dandupalya28795'),(80,'Bahubali 2','Kannada','28th Apr, 2017','Bahubali24522');
/*!40000 ALTER TABLE `movies` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-12 10:44:08
