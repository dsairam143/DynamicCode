from django.contrib import admin
from .models import Movies, Movie_Info,Movie_Verdict
# Register your models here.


class MoviesAdmin(admin.ModelAdmin):
    # list_display = [Movies._meta.get_fields()]
    list_display = ['movie_id', 'name', 'language', 'date', ]


class Movie_Info_Admin(admin.ModelAdmin):
    # list_display = [field.name for field in Movie_Info._meta.get_fields()]
    list_display = ['movie', 'movie_info', 'image_name']


class Movie_Verdict_Admin(admin.ModelAdmin):
    # list_display = [field.name for field in Movie_Verdict._meta.get_fields()]
    list_display = ['movie', 'rating', 'comment', 'verdict_link']


admin.site.register(Movies, MoviesAdmin)
admin.site.register(Movie_Info, Movie_Info_Admin)
admin.site.register(Movie_Verdict, Movie_Verdict_Admin)
