from django.apps import AppConfig


class OnemovieConfig(AppConfig):
    name = 'onemovie'
