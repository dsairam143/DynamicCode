from django.shortcuts import render

# Create your views here.
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from onemovie.models import Movies
from .serializer import MoviesSerializer


# Create your views here.
class IndexView(APIView):
    """
    API view for searching Movies
    """
    allowed_methods = ['GET']
    serializer_class = MoviesSerializer

    def get(self, request, *args, **kwargs):
        queryset = Movies.objects.all()
        # We can filter our movies by name
        name = request.query_params.get('language', None)
        if name is not None:
            queryset = queryset.filter(language=name)

        movie_id = request.query_params.get('movie_id', None)
        if movie_id is not None:
            queryset = queryset.filter(movie_id=movie_id)


        serializer = self.serializer_class(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)