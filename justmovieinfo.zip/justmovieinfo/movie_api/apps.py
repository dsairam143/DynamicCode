from django.apps import AppConfig


class MovieApiConfig(AppConfig):
    name = 'movie_api'
