from rest_framework import serializers
from onemovie.models import Movies, Movie_Info, Movie_Verdict


class Movie_Info_Serializer(serializers.ModelSerializer):
    """
    Serializer for Movie model
    """

    class Meta:
            model = Movie_Info
            fields = '__all__'


class Movie_Verdict_Serializer(serializers.ModelSerializer):
    """
    Serializer for Genre model
    """
    class Meta:
        model = Movie_Verdict
        fields = '__all__'


class MoviesSerializer(serializers.ModelSerializer):
    """
    Serializer for Genre model
    """
    # movie = serializers.StringRelatedField(many=True)
    movie = Movie_Info_Serializer(read_only=True)
    movie_verdict = Movie_Verdict_Serializer(many=True, read_only=True)

    class Meta:
        model = Movies
        fields = '__all__'






