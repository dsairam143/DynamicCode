import requests
from bs4 import BeautifulSoup
from collections import defaultdict



domain = 'https://www.apple.com'
resp = requests.get('https://www.apple.com/newsroom/')
jsoup = BeautifulSoup(resp.content)
body = jsoup.find('body')
chils = body.descendants
classFilters = []
for ch in list(chils)[::-1]:
    if ch.name and not(ch.name=='script'):
        checkAttributes = ['class']
        for ca in checkAttributes:
            if ca in ch.attrs:
                classFilters.append(ch)
                break

classData = []
for cf in classFilters:
    className = ' '.join(cf.attrs['class'])
    classData.append((className, cf))


dict_marks = defaultdict(list)

for key, value in classData:
    dict_marks[key].append(value)

mainData = list(dict_marks.items())
mainList = []
filterList = []

for id, k in enumerate(mainData):
    if len(k[1])>=5:
        mainList.append(k)
        filterList.append(k)
        print(k[0], len(k[1]))
foundIndexes = []
for mid, ml in enumerate(mainList):
    classname = ml[0]
    for fid, fl in enumerate(filterList):
        if mid == fid:
            continue
        # print('fid = ', fid)
        # print(fl[1])
        found = False
        for k in fl[1][0].descendants:
            try:
                print(classname, ' = ', ' '.join(k.attrs['class']))
                if classname == ' '.join(k.attrs['class']):
                    foundIndexes.append(mid)
                    found = True
                    print(' '.join(k.attrs['class']))
            except:
                pass
        if found:
            break
        # break
    # break
    print('=============================================================')
    # print(ml[0])
mainList = [k for id, k in enumerate(mainList) if id not in foundIndexes]

import dateutil.parser as dparser
import re


DateFilterList = []
for k in mainList[1:]:

    dateCOunt = 0
    for l in k[1]:
        # print('=========================================')
        content = l.text
        newdate = re.search('[a-zA-Z\.]* \d?\d, \d{4}|\d{4}[-\.]\d\d[-\.]\d\d|\d\d?[-\/.]\d\d?[-\/.]\d{4}|[a-zA-Z]* \d\d?, [a-zA-Z]* \d{4}|\d\d? [a-zA-Z]*  ?\d{4}',content)
        newdate = newdate.group(0) if newdate else newdate
        if not newdate:
            try:
                newdate = dparser.parse(content, fuzzy=True).strftime('%m-%d-%Y')
            except:
                newdate = None
        if newdate:
            print(newdate)
            dateCOunt+=1
    if dateCOunt>=5:
        print(k[0])
        DateFilterList.append([dateCOunt, k[1]])
    print('Total Date Count = ', dateCOunt)


print('-----------------------------------------')
DateFilterList.sort(key = lambda x:x[0], reverse = True)
def ArticleData(FADATA, FA):
    if FA.name == 'a':
        link = ''
        try:
            link = FA['href']
        except:
            pass
        FADATA.append([FA.name, [FA.text.strip(), link]])

    if FA.name == 'div':
        divs = [k for k in list(FA.findChildren(recursive=False)) if k.name=='div']
        if len(divs)==1:
            if len(FA.text.strip())>2:
                FADATA.append([FA.name, [FA.text.strip()]])

    if FA.name == 'p':
        divs = [k for k in list(FA.findChildren(recursive=False)) if k.name=='p']
        if len(divs)==1:
            if len(FA.text.strip())>2:
                FADATA.append([FA.name, [FA.text.strip()]])
    if FA.name == 'span':
        divs = [k for k in list(FA.findChildren(recursive=False)) if k.name == 'span']
        if len(divs) == 1:
            if len(FA.text.strip()) > 2:
                FADATA.append([FA.name, [FA.text.strip()]])

    if FA.findChildren(recursive=False):
        for ff in FA.findChildren(recursive=False):
            ArticleData(FADATA, ff)
    else:
        # print(FA.name)
        if FA.name == 'a':
            link = ''
            try:
                link = FA['href']
            except:
                pass
            FADATA.append([FA.name, [FA.text.strip(), link]])
        elif FA.name == 'img':
            image = None
            try:
                image = FA['src']
            except:
                pass
            if image:
                FADATA.append([FA.name,[image]])
        else:
            if len(FA.text.strip())>2:
                FADATA.append([FA.name, [FA.text.strip()]])


import pandas as pd
if DateFilterList:

    FinalArticlesData = []
    FinalArticles = DateFilterList[0]
    print('Selected Class = ', FinalArticles[1])
    for FA in FinalArticles[1]:
        print(FA)
        FADATA = []
        # FADATA.append(['mainUrls', FA.find_all('a')])
        FADATA.append(['Urls', [(domain+k['href'] if 'http' not in k['href'] else k['href'])  for k in FA.find_all('a') if 'href' in k.attrs ] ])
        # ArticleData(FADATA, FA)

        dict_marks = defaultdict(list)

        for key, value in FADATA:
            dict_marks[key].append(value)

        result = {k[0]:k[1]for k in list(dict_marks.items())}
        FinalArticlesData.append(result)
        print('FADAT = ', FADATA)
        print('Result = ', result)
        # break



    print(FinalArticlesData)
    for x in FinalArticlesData:
        print(x['Urls'][0][0])
        try:
            # url = (x['Article Links'])


            # For different language newspaper refer above table
            url = 'https://www.apple.com/newsroom/2018/11/the-hiv-positive-caregivers-working-to-end-aids-in-africa/'
            toi_article = Article(url, language="en")  # en for English

            # To download the article
            toi_article.download()

            # To parse the article
            toi_article.parse()

            # To perform natural language processing ie..nlp
            toi_article.nlp()

            # To extract title
            print("Article's Title:")
            print(toi_article.title)
            print("n")

            # To extract text
            print("Article's Text:")
            print(toi_article.text)
            print("n")

            # To extract summary
            print("Article's Summary:")
            print(toi_article.summary)
            print("n")

            # To extract keywords
            print("Article's Keywords:")
            print(toi_article.keywords)

            # To extract keywords
            print("Published Date:")
            print(toi_article.publish_date)
            toi_article_title = re.sub(r'[^\x00-\x7F]', '', toi_article.title if toi_article.title else '').replace(
                '\n', '')
            toi_article_text = re.sub(r'[^\x00-\x7F]', '', toi_article.text if toi_article.text else '').replace('\n',
                                                                                                                 '')
            toi_article_summary = re.sub(r'[^\x00-\x7F]', '',
                                         toi_article.summary if toi_article.summary else '').replace('\n', '')
            toi_keywords = ','.join(toi_article.keywords if toi_article.keywords else '')


            a = [x['Company Name'],x['Company URL'],x['Article Links'],toi_article_title,toi_article.publish_date,toi_article_text,toi_article_summary,toi_keywords]
            Excel_Data.append(a)
        except Exception as e:
            print(e)
    #
    # for k in FinalArticlesData:
    #     print(k)
    # df = pd.DataFrame(FinalArticlesData)
    # df.to_excel('Articles.xlsx', index=False)



# print(FinalArticles)
