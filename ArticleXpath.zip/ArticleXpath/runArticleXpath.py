def xpath_soup(element):
    """
    Generate xpath from BeautifulSoup4 element
    :param element: BeautifulSoup4 element.
    :type element: bs4.element.Tag or bs4.element.NavigableString
    :return: xpath as string
    :rtype: str

    """
    components = []
    child = element if element.name else element.parent
    for parent in child.parents:
        """
        @type parent: bs4.element.Tag
        """
        siblings = parent.find_all(child.name, recursive=False)
        components.append(
            child.name
            if siblings == [child] else
            '%s[%d]' % (child.name, 1 + siblings.index(child))
        )
        child = parent
    components.reverse()
    return '/%s' % '/'.join(components)


if __name__ == '__main__':
    import doctest

    doctest.testmod(verbose=True)

    from bs4 import BeautifulSoup
    import requests
    import pandas as pd
    import re
    response = requests.get('http://investor.acceleronpharma.com/press-releases').content
    # print(response)
    jsoup = BeautifulSoup(response,'lxml')
    elem = jsoup.find_all('a')
    xpath_list = []
    for anchors in elem:
        print(xpath_soup(anchors))

        xpath_list.append(xpath_soup(anchors))
    df = pd.DataFrame(xpath_list, columns=['xpaths'])
    df['count'] = df['xpaths'].apply(lambda x:x.count('/'))

    df.groupby(['count'],as_index=True)
    # for number in df['count']:


    print(df)
    df.to_excel('test.xlsx',index=False)