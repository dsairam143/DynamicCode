# -*- coding: utf-8 -*-
from newspaper import Article
import pandas as pd
import re
# A new article from TOI
Excel_Data = []

table_headers = ['Company_name','Company_url','Article_url','Headline','Published_Date','Content','Summary','tags']
Excel_Data.append(table_headers)

# news = pd.read_excel('10_newsurls_article_test.xlsx')
# news = news.to_dict('records')
for x in range(1):
   try:
       # url = (x['Article Links'])


       # For different language newspaper refer above table
       url = 'https://www.apple.com/newsroom/2018/11/the-hiv-positive-caregivers-working-to-end-aids-in-africa/'
       toi_article = Article(url, language="en")  # en for English

       # To download the article
       toi_article.download()

       # To parse the article
       toi_article.parse()

       # To perform natural language processing ie..nlp
       toi_article.nlp()

       # To extract title
       print("Article's Title:")
       print(toi_article.title)
       print("n")

       # To extract text
       print("Article's Text:")
       print(toi_article.text)
       print("n")

       # To extract summary
       print("Article's Summary:")
       print(toi_article.summary)
       print("n")

       # To extract keywords
       print("Article's Keywords:")
       print(toi_article.keywords)

       # To extract keywords
       print("Published Date:")
       print(toi_article.publish_date)
       toi_article_title = re.sub(r'[^\x00-\x7F]', '', toi_article.title if toi_article.title else '').replace('\n', '')
       toi_article_text = re.sub(r'[^\x00-\x7F]', '', toi_article.text if toi_article.text else '').replace('\n', '')
       toi_article_summary = re.sub(r'[^\x00-\x7F]', '', toi_article.summary if toi_article.summary else '').replace('\n', '')
       toi_keywords = ','.join(toi_article.keywords if toi_article.keywords else '')


       # a = [x['Company Name'],x['Company URL'],x['Article Links'],toi_article_title,toi_article.publish_date,toi_article_text,toi_article_summary,toi_keywords]
       # Excel_Data.append(a)
   except Exception as e:
       print(e)
# df = pd.DataFrame(Excel_Data, columns=table_headers)
# order = ['Company_name','Company_url','Article_url','Headline','Published_Date','Content','Summary','tags']
# df = df[order]
# df.drop_duplicates(keep='first')
# print(df)
# df.to_csv('Final_news_article_data_new.csv', index=False,header=False)