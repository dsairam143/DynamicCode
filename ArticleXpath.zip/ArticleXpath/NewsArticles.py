import requests
from bs4 import BeautifulSoup

class Articles:
    # def __init__(self, url):
    #     self.url = url
    def extractAllClassTags(self, url=None):
        if url:
            resp = requests.get('http://aftermaster.com/news/')
            jsoup = BeautifulSoup(resp.content)
            body = jsoup.find('body')
            chils = body.descendants
            classFilters = []
            for ch in list(chils)[::-1]:
                if ch.name and not (ch.name == 'script'):
                    checkAttributes = ['class']
                    for ca in checkAttributes:
                        if ca in ch.attrs:
                            classFilters.append(ch)
                            break


            classData = []
    pass

art = Articles()
