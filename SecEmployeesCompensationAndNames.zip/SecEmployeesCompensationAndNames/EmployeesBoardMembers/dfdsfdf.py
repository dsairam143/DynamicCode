import pandas as pd
import concurrent.futures
from BoardMemberFromImage import getMembers

def gerBoardMembers(company):
    print(company)
    result = getMembers(company['URL'])
    print("=============================================================================")
    print(company['URL'], result)
    print("=============================================================================")
    return result


df = pd.read_excel('..\\EmployeesNames\\01-22-2019\\CompensationFullData__.xlsx')
df = df.groupby('URL')['Name'].apply(list)
df = df.reset_index()
data = df.to_dict('records')

l = data
n = 100
companies = [l[i:i + n] for i in range(0, len(l), n)]

for comp in companies[2:]:
    try:
        finalData = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            # Start the load operations and mark each future with its URL
            future_to_url = {executor.submit(gerBoardMembers, company): company for company in comp}
            for future in concurrent.futures.as_completed(future_to_url):
                url = future_to_url[future]
                try:
                    data = future.result()
                except Exception as exc:
                    print('%r generated an exception: %s' % (url, exc))
                else:
                    if data:
                        finalData.extend(data)

        print(finalData)
    except:
        pass
    break