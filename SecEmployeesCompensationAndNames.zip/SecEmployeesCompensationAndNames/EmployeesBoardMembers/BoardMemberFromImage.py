import requests
import re
from bs4 import BeautifulSoup

def getMembers(url):
    resp = requests.get(url)
    jsoup = BeautifulSoup(resp.content)
    tables = jsoup.find_all('table')
    trPatterns = []
    Result = []
    for table in tables:
        if table.find('img'):
            for tr in table.find_all('img'):
                for k in range(5):
                    tr = tr.parent
                    if 'tr' == tr.name:
                        text = tr.text.lower()
                        if 'age' in text and 'since' in text:
                            trPatterns.append(tr)
                            since = tr.findChildren(recursive=True)
                            dummyDict = dict()
                            image = tr.find('img')['src']
                            dummyDict['ImageLink'] = image
                            since = since[::-1]
                            qualificationFound = False
                            ageNotFound = False
                            for id, child in enumerate(since):

                                text = child.text.lower()
                                splitText = [re.sub('\W', '', k) for k in text.split()]

                                if 'qualification' in text and not qualificationFound:
                                    # print(text)
                                    dummyDict['Qualification'] = since[id - 1].text+'\n'+child.parent.text
                                    qualificationFound = True
                                if 'age' in splitText and not ageNotFound:
                                    dummyDict['Age'] = since[id].text
                                    ageNotFound = True

                                if 'since' in splitText:
                                    try:
                                        dummyDict['Since'] = since[id].text+'\n'+since[id + 1].text
                                    except:
                                        dummyDict['Since'] = since[id].text

                                if 'committee' in splitText or 'committe' in splitText or 'committees' in splitText:
                                    dummyDict['Committee'] = child.text

                            a = {'ImageLink':dummyDict.get('ImageLink'),
                                 'Age':dummyDict.get('age'),
                                 'Qualification':dummyDict.get('qualification'),
                                 'Since':dummyDict.get('since'),
                                 'Committee':dummyDict.get('committee')}

                            Result.append(a)
    return Result



