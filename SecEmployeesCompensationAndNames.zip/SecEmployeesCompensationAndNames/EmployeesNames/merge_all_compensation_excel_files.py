import pandas as pd
import os
import datetime
today = datetime.datetime.today().strftime('%m-%d-%Y')
files = os.listdir(today)
df = pd.read_excel(today+'\\Compensation Result_0.xlsx')
# df = pd.DataFrame()
for file in files:
    if 'Compensation Result_0' in file:
        continue
    df1 = pd.read_excel(today+'\\'+file)
    df = df.merge(df1, how='outer').fillna(0)
# print(k)

# df.to_excel('CompensationFullData.xlsx', index=False)
# df = pd.read_excel('CompensationFullData.xlsx')
def nameFilter(x):
    if isinstance(x, str):
        if len(x)<5:
            return 0
        else:
            return x
    else:
        return 0

df['Name'] = df['Name'].apply(nameFilter)

df = df.drop(df[df.Name == 0].index)


df.to_excel('CompensationFullData.xlsx')

# a = df.columns.tolist()
# print(a)