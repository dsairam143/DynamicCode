import requests
import re
import pandas as pd
import numpy as np
import math
from bs4 import BeautifulSoup
from tableData import tableDataExtractor
from datetime import datetime
today = datetime.today().strftime('%d-%m-%Y')
from memory_profiler import profile
import os

# @profile
def getCompensationDetails(url):
    # clear = lambda: os.system('dir')
    # clear()
    # print('Inside = ', url)
    cik = re.search('data/(\d+)/', url)
    if cik:
        cik = cik.group(1)
    # print(cik)
    imageLink = url[:url.rindex('/')]
    resp = requests.get(url)
    jsoup = BeautifulSoup(resp.content)
    tables = jsoup.find_all('table')
    # dummyDict = dict()

    for table in tables:
        # print(table.text)
        text = table.text.lower()
        if 'fees' in text and 'name' in text and 'award' in text and 'total' in text:
            # print(table)
            result = tableDataExtractor(table)
            # print(result)
            # print('=============================================================================')
            col = []
            for id, k in enumerate(result[0]):
                a = 'Col_'+str(id)
                col.append(a)
            df = pd.DataFrame(result, columns=col)
            df = df[df['Col_0']!=None]
            df = df[df['Col_0'] !=None]
            df = df.dropna(axis=1, how='all', inplace=False)
            df = df.dropna(axis=0, how='all', inplace=False)

            #Filter Extra Columns Data And Remove Empty Columns
            data = df.values.tolist()
            check = data[0]
            result = []
            result.append(check)
            for d in data[1:]:
                # print(d)
                dummyList = []
                for id, value in enumerate(d):

                    if check[id] is not None:

                        if value is None:

                            if check[id+1] is None:
                                # print(d[id+1])
                                d[id] = d[id+1]
                                d[id+1] = None
                                dummyList.append(d)
                result.append(d)

            # print(result)
            df = pd.DataFrame(result, columns=df.columns.tolist())
            df = df.dropna(axis=1, how='all', inplace=False)
            df = df.dropna(axis=0, how='all', inplace=False)
            finalResult = df.values.tolist()
            df = pd.DataFrame(finalResult[1:], columns=[k.replace('\n', ' ')for k in finalResult[0]])

            renames = [['name', 'Name'], ['fees', 'FEES EARNED OR PAID IN CASH($)'], ['stock', 'Stock Or Share Based Awards($)'],['share', 'Stock Or Share Based Awards($)'], ['total', 'Total'], ['other', 'Other Compensations'],
                       ['option awards', 'Option Awards'], ['optionawards', 'Option Awards'], ['nonqualified', 'Chang in Pension Value and Nonqualified Deferred Compensation Earnings'],
                       ['non-equity', 'Non-Equity Incentive Plan Compensation']]
            renameDict = dict()
            for ren in renames:
                for k in df.columns.tolist():
                    if ren[0] in k.lower():
                        if ren[0] == 'stock' or ren[0] == 'share':
                            if 'award' not in k.lower():
                                continue
                        renameDict[k] = ren[1]
                        break
            df.rename(columns=renameDict, inplace=True)
            df['CIK'] = cik
            df['Date'] = today
            df['URL'] = url
            try:
                df['FEES EARNED OR PAID IN CASH($)']
                df['Stock Or Share Based Awards($)']

                return df
            except:
                pass




# urls = [
#         'https://www.sec.gov/Archives/edgar/data/811831/000143774918017942/nbn20180924_def14a.htm'
#         'https://www.sec.gov/Archives/edgar/data/1160308/000119312518126480/d551281ddef14a.htm'
#         'https://www.sec.gov/Archives/edgar/data/1087423/000119312518201605/d521559ddef14a.htm',
#         'https://www.sec.gov/Archives/edgar/data/1630805/000163080518000061/bw2018definitiveproxyaprdoc.htm',
#         'https://www.sec.gov/Archives/edgar/data/1385849/000106299318001583/def14a.htm',
#         'https://www.sec.gov/Archives/edgar/data/46619/000004661918000010/fye2017formdef14a.htm'
#         ]*10
# dataList = []
#
#
# for url in urls:
#
#
#     d = getCompensationDetails(url)
#     print(d)
#     if d is not None:
#         dataList.append(d)
