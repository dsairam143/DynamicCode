import os
import requests
import re
import pandas as pd
from tableData import tableDataExtractor
from bs4 import BeautifulSoup
from datetime import datetime
employess_path = today+'_employess'
if not os.path.exists(employess_path):
    os.makedirs(employess_path)

today = datetime.today().strftime('%d-%m-%Y')
keys = pd.read_excel('keys.xlsx')
keys = keys.to_dict('records')

# print(keys)
rawResult = []
def checkKey(text):
    combination = []
    for key in keys:
        # print(key.values())
        found = False
        for k in key.values():
            if not isinstance(k, str) or key == True or k.lower() == 'true':
                continue

            if k not in text:

                found = True
        if not found:
            combination.append([True, key])
        else:
            combination.append([False, key])


    if any([k[0] for k in combination]):
        # print(text)
        return [k for k in combination if True==k[0]][0]
    else:
        return [False, []]





df = pd.read_excel('CompensationFullData.xlsx')
df = df.groupby('URL')['Name'].apply(list)
df = df.reset_index()
data = df.to_dict('records')
print(len(data))
l = data
n = 100
companies = [l[i:i + n] for i in range(0, len(l), n)]
FinalResult= []
tableNotFound = []
for comp in companies:
    for _id, url in enumerate(comp):
        try:
            print(url)
            cik = re.search('data/(\d+)/', url['URL'])
            if cik:
                cik = cik.group(1)
            print('=====================================================================')
            print(url['URL'])
            tHeaders = None
            resp = requests.get(url['URL'])
            # resp = requests.get('https://www.sec.gov/Archives/edgar/data/726513/000119312518121966/d543685ddef14a.htm')
            jsoup = BeautifulSoup(resp.content)

            tables = jsoup.find_all('table')
            found = False
            for table in tables:
                # print(table.text.lower())
                text = table.text.lower()
                # print(text)
                checked = checkKey(text)
                # print(checked)
                if True:
                    tableResult = tableDataExtractor(table)

                    if not tableResult:
                        continue

                    if len(tableResult[0])>=3:
                        # print(tableResult)
                        # goodCombination = [i for i in checked[1].values() if isinstance(i, str)]
                        # print(goodCombination)
                        tableHeaders = None
                        for id, k in enumerate(tableResult):
                            if isinstance(k[0], str):
                                if len(k[0])<3:
                                    continue
                                tableHeaders = [i.lower() if isinstance(i, str) else i for i in k]
                                tableResult = tableResult[id+1:]
                                break

                        # print(tableHeaders)
                        goodCheck = 0
                        # for k in goodCombination:
                        #
                        #     for i in tableHeaders:
                        #         if not isinstance(i, str):
                        #             continue
                        #         if k in i:
                        #             goodCheck+=1

                        # if goodCheck>=len(goodCombination):
                        if True:
                            for ck in keys:
                                nameItems = ck
                                # nameItems = checked[1].copy()
                                nameItems = [['Since',nameItems['Since']], ['Age',nameItems['Age']], ['Name', nameItems['Name']], ['Position', nameItems['Position']]]

                                nameFound = 0
                                # print(tableHeaders)
                                for id, head in enumerate(tableHeaders):
                                    if not isinstance(head, str):
                                        continue
                                    # if nameItems['Name'] in head.lower():
                                    #     nameFound = True

                                    for k in nameItems:
                                        # print(k)
                                        if not isinstance(k[1], str):
                                            continue
                                        if k[1].lower() in head.lower():
                                            # print('Found = ', k)
                                            tHeaders = tableHeaders
                                            # if k[0] != 'Name':
                                            #     tHeaders[id] = k[0]
                                            # print(k[0], nameItems)
                                            nameItems.remove(k)
                                            nameFound+=1
                                            break
                                # print('Combinations = ', nameFound)
                                if nameFound < 3:
                                    continue
                                else:
                                    # print(nameItems)
                                    break
                            # print('Combinations = ', nameFound)
                            if nameFound<3:
                                continue
                            print('final =- ', tHeaders)
                            df = pd.DataFrame(tableResult, columns=tHeaders)
                            df['URL'] = url['URL']
                            df['Date'] = today
                            df['CIK'] = cik
                            df.to_excel(employess_path+'\\rawData\\rawResult-'+str(cik)+'.xlsx', index=False)
                            # renames = [['name', 'Name']]
                            # renameDict = dict()
                            # for ren in renames:
                            #     for k in df.columns.tolist():
                            #         if ren[0] in k.lower():
                            #             if ren[0] == 'stock' or ren[0] == 'share':
                            #                 if 'award' not in k.lower():
                            #                     continue
                            #             renameDict[k] = ren[1]
                            #             break
                            # df.rename(columns={df.columns.tolist()[0]:'Names'}, inplace=True)
                            # cols = df.columns.tolist()
                            # if 'Names' not in cols:
                            #     df['Names'] = None
                            # if 'Age' not in cols:
                            #     df['Age'] = None
                            # if 'Position' not in cols:
                            #     df['Position'] = None
                            # if 'Since' not in cols:
                            #     df['Since'] = None
                            # df['Date'] = today
                            # df['CIK'] = cik
                            # order = ["Date", "Names", "Age", "Position", "Since", "CIK", "URL"]
                            #
                            # rawResult.append(df)
                            # df = df[order]
                            # print(df)
                            # FinalResult.append(df)


                            # df.to_excel('28-01-2019\\rawFilterData\\rawData-'+str(cik)+'.xlsx', index=False)




                            # df.to_excel('text-'+str(_id)+'.xlsx', index=False)
                            found = True
                            break
            if not found:
                tableNotFound.append(url)
        except Exception as e:
            print(e)
            tableNotFound.append(url)
        # break
    # break
tf = pd.DataFrame(tableNotFound)
tf.to_excel('TableNotFound.xlsx', index=False)
#
# finalDf = pd.concat(FinalResult)
# finalDf.to_excel('rawData.xlsx', index=False)
#
# finalDf = pd.concat(rawResult)
# finalDf.to_excel('rawResult-2.xlsx', index=False)

# finalDf = finalDf[finalDf['Name'] is nan]