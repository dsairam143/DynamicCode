import os
import pandas as pd
from datetime import datetime
import numpy as np
from datetime import datetime
today = datetime.today().strftime('%d-%m-%Y')
employess_path = today+'_employess'

folder = employess_path
files = os.listdir(folder)
reslut = []
for file in files:
    print(file)
    df = pd.read_excel(folder+'\\'+file)
    dfName = df.iloc[:,0]
    dfothers = df.iloc[:,1:]

    originalCols = dfothers.columns.tolist()
    cols = dfothers.columns.tolist()
    for id, col in enumerate(cols):
        if 'since' in col.lower():
            cols[id] = 'Since'
            break
    # print(cols)
    renameCols = dict(zip(originalCols, [k.title() for k in cols]))
    dfothers.rename(columns=renameCols, inplace=True)


    positionKeys = ['occupation', 'position', 'title', 'affiliation', 'director', 'officer', 'nominee']
    originalCols = dfothers.columns.tolist()
    cols = dfothers.columns.tolist()
    if 'Position' not in cols:

        for pkey in positionKeys:
            found = False
            for id, col in enumerate(cols):
                if pkey in col.lower():
                    cols[id] = 'Position'
                    found = True
                    break
            if found:
                break
        renameCols = dict(zip(originalCols, cols))
        dfothers.rename(columns=renameCols, inplace=True)

    # print(renameCols)
    dfothers['Name'] = dfName
    # print(dfothers)
    # dfothers['Date'] = today
    order = ["Date", "Name", "Age", "Position", "Since", "Url", "Cik"]
    cols = dfothers.columns.tolist()
    if 'Name' not in cols:
        dfothers['Name'] = None
    if 'Age' not in cols:
        dfothers['Age'] = None
    if 'Position' not in cols:
        dfothers['Position'] = None
    if 'Since' not in cols:
        dfothers['Since'] = None

    df = dfothers[order]
    reslut.append(df)
    # break

for k in reslut:
    print(k.columns.tolist())
df = pd.concat(reslut)
df.to_excel('finalFilteredData.xlsx', index=False)
#======================================Employees Filter====================================
import re
df = pd.read_excel('finalFilteredData.xlsx')
df = pd.read_excel('CompensationFullData.xlsx')

df = df[pd.notnull(df['Name'])]
unknownCharacters = ['nominee', 'chairman', 'officer', 'former', 'company', 'other', 'independent', 'director',
                     'retired', 'president', 'professor', 'nominated', 'investment', 'committee', 'meetings',
                     'common stock', 'proposal', 'and', 'nomina', 'year', 'meet', 'public', 'ceo', 'partner',
                     'member', 'class', 'expiring', 'board']
unknownStrips = ['*', '-', ' .', '.']
def nameFilter(x):
    if isinstance(x, str):
        for uc in unknownCharacters:
            if uc in x.lower():
                return None

        if len(x)<5:
            return None
        splitters = [',', '(']
        x = x.replace('\n', ' ')

        for sp in splitters:
            if sp in x:
                x = x[:x.index(sp)]
        if len(x)>5:
            x = x.strip()
            for k in range(len(unknownStrips)):
                for st in unknownStrips:
                    x = x.strip(st)
            return x
        else:
            return None
    else:
        return None

def newId(x):
    if isinstance(x, str):
        x = re.sub('\W', '_', re.sub(' +', ' ', x)).lower()
        return re.sub('_+', '_', x)
    return x

df['Name'] = df['Name'].apply(nameFilter)
df = df.dropna(axis=0, subset=['Name'])
df['NameId'] = df['Name'].apply(newId)
df.to_excel('finalFilteredData_.xlsx', index=False)


#=================================Compensation Filter===================================================
import re

df = pd.read_excel('CompensationFullData.xlsx')


unknownCharacters = ['nominee', 'chairman', 'officer', 'former', 'company', 'other', 'independent', 'director',
                     'retired', 'president', 'professor', 'nominated', 'investment', 'committee', 'meetings',
                     'common stock', 'proposal', 'and', 'nomina', 'year', 'meet', 'public', 'ceo', 'partner',
                     'member', 'class', 'expiring', 'board']
unknownStrips = ['*', '-', ' .', '.']
def nameFilter(x):
    if isinstance(x, str):
        for uc in unknownCharacters:
            if uc in x.lower():
                return None

        if len(x)<5:
            return None
        splitters = [',', '(']
        x = x.replace('\n', ' ')
        for sp in splitters:
            if sp in x:
                x = x[:x.index(sp)]
        if len(x)>5:
            x = x.strip()
            for k in range(len(unknownStrips)):
                for st in unknownStrips:
                    x = x.strip(st)
            return x
        else:
            return None
    else:
        return None

def newId(x):
    if isinstance(x, str):
        x = re.sub('\W', '_', re.sub(' +', ' ', x)).lower()
        return re.sub('_+', '_', x)
    return x

df['FilterName'] = df['Name'].apply(nameFilter)
df['NameId'] = df['FilterName'].apply(newId)

order = ['Date','CompanyName', 'CIK', 'Name', 'FilterName', 'NameId', 'FEES EARNED OR PAID IN CASH($)','Stock Or Share Based Awards($)','Total', 'URL']
col = df.columns.tolist()

for ren in order:
    try:
        col.remove(ren)
    except:
        pass

order.extend(col)

result = df[order]
result = result.dropna(axis=1, how='all', inplace=False)
result = result.dropna(axis=0, how='all', inplace=False)
newOrder = []
for k in result.columns.tolist():
    if isinstance(k, str):
        if len(k)>2:
            newOrder.append(k)
result = result[newOrder]


result.to_excel('CompensationFilteredData_.xlsx', index=False)