
from bs4 import BeautifulSoup
from tableData2 import tableDataExtractor2
import requests
def getSubUrls(filterList):
    subUrls = []
    for fl in filterList:
        filteredUrl = fl[1]
        # print('Main Url = ', filteredUrl)
        subTable = BeautifulSoup(requests.get(filteredUrl).content).find('table', attrs={'class': 'tableFile'}).parent
        # print(subTable)
        subTableData = tableDataExtractor2(subTable)
        # print(subTableData)
        for l in subTableData:
            u = l[2][1]
            if u:
                if '.htm' in u:
                    # print(u)
                    subUrls.append([fl[0], 'https://www.sec.gov'+u])

    return subUrls
# url = [['8-K', 'https://www.sec.gov/Archives/edgar/data/1060744/000110465903025160/0001104659-03-025160-index.htm'], ['10-K', 'https://www.sec.gov/Archives/edgar/data/1060744/000110465903005536/0001104659-03-005536-index.htm'], ['10-Q', 'https://www.sec.gov/Archives/edgar/data/1060744/000110465903026709/0001104659-03-026709-index.htm']]
# d = getSubUrls(url)
# print(d)