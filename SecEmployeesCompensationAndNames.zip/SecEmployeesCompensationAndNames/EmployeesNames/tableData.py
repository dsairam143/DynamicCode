import re
def tableDataExtractor(table, WithLink = None):
    if table.find_all('tr'):
        # print('found')
        # table = table.find('table')

        trs = table.find_all('tr')
        nooftd = 0
        for tr in trs:
            tds = tr.find_all(re.compile('th|td'))
            if len(tds) > nooftd:
                nooftd = len(tds)
        trList = []
        for tr in trs:
            tds = tr.find_all(re.compile('th|td'))
            tdList = []
            for td in tds:
                colspan = 0
                try:
                    colspan = int(td['colspan'])
                except:
                    pass
                if colspan != 0:
                    a = td.text.strip()
                    a = None if len(a)==0 else a
                    tdList.append(a)
                    for k in range(colspan - 1):
                        tdList.append(None)
                else:
                    if WithLink:
                        link = td.find('a')['href'] if td.find('a') else None
                        tdList.append([td.text.strip(), link])
                    else:
                        b = td.text.strip()
                        b = re.sub(r'[^\x00-\x7F]', '', b)
                        b = re.sub(' +', ' ', b).strip()
                        b = None if len(b)==0 else b
                        tdList.append(b)
            trList.append(tdList)
        return trList