import pandas as pd
import concurrent.futures
import urllib.request
import datetime
import sys
import os
import gc
from mainRoute import getFullData

def load_company(company):
    print(company)
    result = getFullData(company)
    return result


if __name__ == '__main__':
    import time
    count = 2
    today = datetime.datetime.today().strftime('%m-%d-%Y')
    df = pd.read_excel("CompanyCiks.xlsx")
    companies = df.to_dict('records')
    output = os.getcwd()+'\\output\\'+today
    if not os.path.exists(output):
        os.makedirs(output)

    s = time.time()
    l = companies
    n = 100
    companies = [l[i:i + n] for i in range(0, len(l), n)]

    for id, compan in enumerate(companies):
        try:
            finalData = []
            with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
                # Start the load operations and mark each future with its URL
                future_to_url = {executor.submit(load_company, company): company for company in compan}
                for future in concurrent.futures.as_completed(future_to_url):
                    url = future_to_url[future]
                    try:
                        data = future.result()
                    except Exception as exc:
                        print('%r generated an exception: %s' % (url, exc))
                    else:
                        if data is not None:
                            finalData.append(data)



            if finalData:
                df1 = finalData[0]
                for k in finalData[1:]:
                    try:
                        df1 = df1.merge(k, how='outer').fillna(0)
                    except:
                        pass
                result = df1
                order = ['Date','CompanyName', 'CIK', 'Name', 'FEES EARNED OR PAID IN CASH($)','Stock Or Share Based Awards($)','Total', 'URL']
                col = result.columns.tolist()

                for ren in order:
                    try:
                        col.remove(ren)
                    except:
                        pass

                order.extend(col)

                result = result[order]
                result = result.dropna(axis=1, how='all', inplace=False)
                result = result.dropna(axis=0, how='all', inplace=False)
                newOrder = []
                for k in result.columns.tolist():
                    if isinstance(k, str):
                        if len(k)>2:
                            newOrder.append(k)
                result = result[newOrder]
                result.to_excel(output+'\\Compensation Result_'+str(id)+'.xlsx', index=False)


                gc.collect()
                print('Loop Completed Check The Memory')
                del finalData
                time.sleep(3)

            else:
                print('Data Not Found')

        except Exception as e:
            print(e)

    print('Total Execution Time is ', time.time()-s)