import pandas as pd
import requests
import re
from bs4 import BeautifulSoup
from SecondCheck import SecondChec
from tableData2 import tableDataExtractor2
from EmployeesCompensation import getCompensationDetails
from subUrls import getSubUrls
import datetime
import os

today = datetime.datetime.today().strftime('%m-%d-%Y')
if not os.path.exists(today):
    os.makedirs(today)

headers = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36"}

# finalResultData = []
# failedList = []
compniesWithCIK = []

def getFullData(com):
    # clear = lambda: os.system('dir')
    # clear()
    FullData = dict()
    # url = 'https://www.sec.gov/cgi-bin/browse-edgar?CIK='+str(com[2])
    url = 'https://www.sec.gov/cgi-bin/browse-edgar?company='+str(com['name']).replace('&', '%26').replace(' ', '+')+'&owner=exclude&action=getcompany'

    url = 'https://www.sec.gov/cgi-bin/browse-edgar?CIK='+str(com['cik'])+'&owner=exclude&action=getcompany&Find=Search'
    # print(url)

    jsoup = BeautifulSoup(requests.get(url, headers=headers).content)
    companyName = jsoup.find('span', attrs={'class':'companyName'})
    companyName = companyName.text if companyName else companyName
    table = jsoup.find('div', attrs={'id':'seriesDiv'})
    #If Company not found in first attempt try it in another way.
    if not companyName:
        secondData = SecondChec(com['name'])
        if not secondData['companyName']:
            # failedList.append([com['Company Name'], 'Not Found'])
            FullData['OriginalName'] = com['name']
            FullData['SecName'] = None
            FullData['CIK'] = None
            FullData['Form'] = None
            FullData['MainReference'] = None
            FullData['SubReference'] = None
            FullData['Link'] = None
            # FullData['Company'] = {'OriginalName': com['Company Name']}
            return None

        else:
            companyName = secondData['companyName']
            table = secondData['table']
            url = secondData['url']

    companyName = re.search('(.*)CIK[^\d]*([0-9]+).*', companyName)
    company_Name = companyName.group(1)
    CIK = companyName.group(2)
    compniesWithCIK.append([com['name'],company_Name, CIK])
    FullData['OriginalName'] = com['name']
    FullData['SecName'] = company_Name
    FullData['CIK'] = CIK
    # FullData['Company'] = {'OriginalName':com['Company Name'], 'SecName':company_Name, 'CIK':CIK}
    # print(table)
    tableData =tableDataExtractor2(table)


    # List of files for find Address
    filterList = []
    for i in ['DEF 14A']:
        for k in tableData:
            if i in k[0]:
                formName = k[0][0]
                url = 'https://www.sec.gov'+k[1][1]
                if '.htm' in url or '.txt' in url:
                    filterList.append([formName, url])
                    break

    if filterList:
        filterList = getSubUrls(filterList)
        if filterList:
            for k in filterList:
                print(k)
                # return None
                result = getCompensationDetails(k[1])
                if result is not None:
                    result['CIK'] = CIK
                    result['CompanyName'] = com['name']
                    # del getCompensationDetails
                    # return None
                    # del filterList
                    return result


# #
# test = {'Company Name': 'RED HAT INC'}
# t = getFullData(test)
# print('result = ',t)
