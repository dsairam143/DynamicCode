import pandas as pd
import concurrent.futures
import urllib.request
import datetime
from mainRoute import getFullData

def load_company(company):
    print(company)
    result = getFullData(company)
    print('Final Result = ', result)
    print(company)
    return result


if __name__ == '__main__':
    import time

    today = datetime.datetime.today().strftime('%m-%d-%Y')
    df = pd.read_excel("List of Sample 100 companies.xlsx")
    companies = df.to_dict('records')
    # print(companies)
    s = time.time()
    finalData = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        # Start the load operations and mark each future with its URL
        future_to_url = {executor.submit(load_company, company): company for company in companies}
        for future in concurrent.futures.as_completed(future_to_url):
            url = future_to_url[future]
            try:
                data = future.result()
            except Exception as exc:
                print('%r generated an exception: %s' % (url, exc))
            else:
                finalData.append(data)
                print('%r page is %d bytes' % (url, len(data)))

    df = pd.DataFrame(finalData)
    df['Date'] = datetime.datetime.today().strftime('%m-%d-%Y')
    order = ['Date', 'OriginalName', 'SecName', 'CIK', 'Form','Link', 'MainReference', 'SubReference']
    df = df[order]
    df.to_excel('SecEmployeesData-'+today+'.xlsx', index=False)

    print('Total Execution Time = ', time.time()-s)