import pandas as pd
import requests
import re
from bs4 import BeautifulSoup
from SecondCheck import SecondChec
from tableData import tableDataExtractor
from employeesText import getEmployees
from subUrls import getSubUrls
import datetime
import os

today = datetime.datetime.today().strftime('%m-%d-%Y')
if not os.path.exists(today):
    os.makedirs(today)

headers = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36"}

# finalResultData = []
# failedList = []
compniesWithCIK = []

def getFullData(com):

    FullData = dict()
    # url = 'https://www.sec.gov/cgi-bin/browse-edgar?CIK='+str(com[2])
    url = 'https://www.sec.gov/cgi-bin/browse-edgar?company='+str(com['Company Name']).replace('&', '%26').replace(' ', '+')+'&owner=exclude&action=getcompany'
    # print(url)

    jsoup = BeautifulSoup(requests.get(url, headers=headers).content)
    companyName = jsoup.find('span', attrs={'class':'companyName'})
    companyName = companyName.text if companyName else companyName
    table = jsoup.find('div', attrs={'id':'seriesDiv'})
    #If Company not found in first attempt try it in another way.
    if not companyName:
        secondData = SecondChec(com['Company Name'])
        if not secondData['companyName']:
            # failedList.append([com['Company Name'], 'Not Found'])
            FullData['OriginalName'] = com['Company Name']
            FullData['SecName'] = None
            FullData['CIK'] = None
            FullData['Form'] = None
            FullData['MainReference'] = None
            FullData['SubReference'] = None
            FullData['Link'] = None
            # FullData['Company'] = {'OriginalName': com['Company Name']}
            return FullData

        else:
            companyName = secondData['companyName']
            table = secondData['table']
            url = secondData['url']

    companyName = re.search('(.*)CIK[^\d]*([0-9]+).*', companyName)
    company_Name = companyName.group(1)
    CIK = companyName.group(2)
    compniesWithCIK.append([com['Company Name'],company_Name, CIK])
    FullData['OriginalName'] = com['Company Name']
    FullData['SecName'] = company_Name
    FullData['CIK'] = CIK
    # FullData['Company'] = {'OriginalName':com['Company Name'], 'SecName':company_Name, 'CIK':CIK}
    # print(table)
    tableData =tableDataExtractor(table)


    # List of files for find Address
    filterList = []
    for i in ['8-K', '10-K', '10-Q', '20F', 'DEF 14A']:
        for k in tableData:
            if i in k[0]:
                formName = k[0][0]
                url = 'https://www.sec.gov'+k[1][1]
                if '.htm' in url or '.txt' in url:
                    filterList.append([formName, url])
                    # print(k[0])
                    break


    # for k in tableData:
    #     if k[1][1]:
    #         formName = k[0][0]
    #         url = 'https://www.sec.gov' + k[1][1]
    #         if '.htm' in url or '.txt' in url:
    #             filterList.append([formName, url])
                # print(k[0])
                # break

    if filterList:
        filterList = getSubUrls(filterList)
        if filterList:
            emp = getEmployees(filterList)
            if emp:
                FullData['Form'] = emp[0]
                FullData['MainReference'] = emp[1]
                FullData['SubReference'] = emp[2]
                FullData['Link'] = emp[3]
            else:
                FullData['Form'] = None
                FullData['MainReference'] = None
                FullData['SubReference'] = None
                FullData['Link'] = None
        else:
            FullData['Form'] = None
            FullData['MainReference'] = None
            FullData['SubReference'] = None
            FullData['Link'] = None
    else:
        FullData['Form'] = None
        FullData['MainReference'] = None
        FullData['SubReference'] = None
        FullData['Link'] = None
    return FullData

#
# test = {'Company Name': 'MIKROS SYSTEMS CORP'}
# t = getFullData(test)
# print('result = ',t)
