import re
def tableDataExtractor(jsoup):
    if jsoup.find('table'):
        # print('found')
        table = jsoup.find('table')

        trs = table.find_all('tr')
        nooftd = 0
        for tr in trs:
            tds = tr.find_all(re.compile('th|td'))
            if len(tds) > nooftd:
                nooftd = len(tds)
        trList = []
        for tr in trs:
            tds = tr.find_all(re.compile('th|td'))
            tdList = []
            for td in tds:
                colspan = 0
                try:
                    colspan = int(td['colspan'])
                except:
                    pass
                if colspan != 0:
                    tdList.append(td.text)
                    for k in range(colspan - 1):
                        tdList.append('')
                else:
                    link = td.find('a')['href'] if td.find('a') else None
                    tdList.append([td.text, link])

            trList.append(tdList)
        return trList