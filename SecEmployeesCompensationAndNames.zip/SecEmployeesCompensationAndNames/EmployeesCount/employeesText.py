import requests
import re
from bs4 import BeautifulSoup

def getEmployees(urls):
    print('Url = ', urls)
    # urls = [['8-K', 'https://www.sec.gov/Archives/edgar/data/944480/000094448018000007/form10k.htm'],
    #         ['8-K', 'https://www.sec.gov/Archives/edgar/data/1408146/000106299318001011/form10k.htm']]
    reference = []
    mainReference = []
    for url in urls:

        resp = requests.get(url[1])

        jsoup = BeautifulSoup(resp.content, 'html.parser')

        mainReference = [k for k in re.findall('[0-9,]+ employees', jsoup.text.lower()) if re.search('\d', k)]

        searchKeys = ['approximately',' had ', 'individuals', 'part-time']
        employees = jsoup.find_all(text=re.compile('employees'))


        for employee in employees:
            emp = employee
            empCount = emp.count('employees')
            if empCount==1:
                mainEmp = emp[:emp.index('employees')+len('employees')]
                subEmp = emp[emp.index('employees') + len('employees'):]
                subEmp = subEmp.split('.')
                mainEmp = mainEmp+subEmp[0]
                d = re.search('[a-zA-Z\.]* \d?\d, \d{4}|\d{4}[-\.]\d\d[-\.]\d\d|\d\d?[-\/.]\d\d?[-\/.]\d{4}|[a-zA-Z]* \d\d?, [a-zA-Z]* \d{4}|\d\d? [a-zA-Z]*  ?\d{4}',mainEmp)
                mainEmp = re.sub('[a-zA-Z\.]* \d?\d, \d{4}|\d{4}[-\.]\d\d[-\.]\d\d|\d\d?[-\/.]\d\d?[-\/.]\d{4}|[a-zA-Z]* \d\d?, [a-zA-Z]* \d{4}|\d\d? [a-zA-Z]*  ?\d{4}','', mainEmp)
                mainEmp = re.sub('\$[0-9\.,]+', '', mainEmp)

                front = mainEmp[:mainEmp.index('employee')]
                back = mainEmp[mainEmp.index('employee'):]
                if '.' in front:

                    front = front[front.rindex('.') + 1:]
                mainEmp = front + back


                # print(mainEmp)
                digitFound = re.search('\d', mainEmp)
                if digitFound:

                    for key in searchKeys:
                        if key in mainEmp:
                            reference.append([url[1],mainEmp])

        if mainReference:
            return url[0],mainReference, reference, url[1]
    return url[0],None, reference if reference else None, None
# urls = [['8-K', 'https://www.sec.gov/Archives/edgar/data/944480/000094448018000007/form10k.htm'], ['8-K', 'https://www.sec.gov/Archives/edgar/data/1408146/000106299318001011/form10k.htm']]
# data = getEmployees(urls)
# print(data)