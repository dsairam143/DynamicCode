# URLconf
from django.urls import path

from . import views

urlpatterns = [
    # path('blog/', views.Home),
    # path('name/',views.Name),
    # path('login-panjsdbkfbksdbkf-sdfilds/',views.Login, name="login-page"),
    # path('my-home-page/',views.Home2, name="home"),
    path('blog/', views.Home),
    path('movie-info/', views.Movie_info, name="movie-info"),

]