from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def Home(request):
    home_movies = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    return render(request, 'my_templates/home.html', {'home_movies':home_movies})

def Movie_info(request):

    return render(request, 'my_templates/movie-info.html')
# def Name(request):
#     return HttpResponse('<h1>Hello Bhanu </h1>')
#
# def Login(request):
#     return render(request, 'login.html')
#
# def Home2(request):
#     return render(request, 'home2.html')