import pandas as pd
import math
import numpy as np
import re


def adjust_columns():
    '''
    It is used to remove empty columns and does some calculation.
    :return:
    '''
    # Read Excel File
    df = pd.read_excel('test3.xlsx')
    df = df.fillna(math.nan)

    # Make Headings
    start_h = 0
    print(df[0])
    for id, h in enumerate(df[0].isnull()):
        if not h:
            start_h = id - 1
            if start_h <= 0:
                start_h = 0
            break

    if start_h != 0:
        heads = df[:start_h + 1]
        dummylist = []
        for m in heads.iterrows():
            f = [k if isinstance(k, str) else '' for k in m[1]]
            dummylist.append(f)

        aa = dummylist[0]
        for mm in dummylist[1:]:
            aa = list(zip(aa, mm))


        sub_row = []
        for sr in aa:
            try:
                print(sr)
                found = False
                for k in sr[::-1]:
                    if len(k) != 0:
                        sub_row.append(k)
                        found = True
                        break
                if not found:
                    sub_row.append(math.nan)
            except:
                pass
        df.loc[start_h] = pd.Series(sub_row)
        df = df.fillna(math.nan)


    # Remove Extra columns.
    for col in df:
        try:
            if col == 0:
                continue
            col_1 = df[col]
            col_2 = df[col + 1]

            if col_2.isnull()[start_h]:
                b = ['' if k[0] else str(k[1]) for k in zip(col_2.isnull(), col_2)]
                a = ['' if k[0] else str(k[1]) for k in zip(col_1.isnull(), col_1)]
                a = pd.Series(a) + pd.Series(b)
                df[col] = a

        except:
            pass

    # Make single line heading
    df2 = df
    df = df.replace('', math.nan, regex=True)
    for col in df:
        if col == 0:
            continue
        if df[col].isnull()[start_h]:
            del df2[col]

    df2 = df2.replace('', math.nan, regex=True)

    df2[:start_h].ffill(axis=1, inplace=True)

    start_h = 0 if start_h == 0 else start_h
    if start_h != 0:
        headings = df2[:start_h + 1].values.tolist()
        a = headings[0]
        print(a)

        for head in headings[1:]:
            a = list(zip(a, head))
        main_headings = []
        for l in [set(k) for k in a]:
            h = ':'.join([m if isinstance(m, str) else 'Heading' for m in list(l)]).strip()
            main_headings.append(h)
    else:
        main_headings = df2[:start_h + 1].values.tolist()[0]
        main_headings = [m if isinstance(m, str) else 'Heading' for m in main_headings]


    # Add Heading And Get Results.
    for k_id, k in enumerate(main_headings):
        count = 0
        for l_id, l in enumerate(main_headings):
            if k == l and k_id != l_id:
                print(k)
                main_headings[l_id] = k + '_' + str(count)
                count += 1

    df2.loc[start_h] = main_headings
    df2 = df2[start_h:]
    df2.columns = df2.iloc[0]
    df2 = df2[1:]
    return df2

df = adjust_columns()
df.to_excel('fffffff.xlsx', index=False)
