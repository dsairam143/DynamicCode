import requests
from bs4 import BeautifulSoup
import dateutil.parser as dparser
import re
from geotext import GeoText
from datetime import datetime

today = datetime.today().year

def ExtractIncAndDom(x):
    data = x
    #     print(data)
    data = re.sub('-+', '', data).strip()
    data = re.sub(' +', ' ', data).strip()
    result = re.search('\(state .+incorporation[^\(]*\)', data)
    try:
        split_result = re.split('\(state .+incorporation[^\(]*\)|state of incorporation|jurisdiction', data)
        incorp = None
        if len(split_result) != 1:
            incorp = split_result[0].replace('state or other', '')
            incorp = re.sub('\([^\)]*\)', ' ', incorp)
            incorp = re.sub('\(.*', ' ', incorp)
            incorpAddr = re.findall('([a-z ]+)[0-9]*', incorp.strip())
            if incorpAddr:
                for k in incorpAddr[::-1]:
                    if len(k.strip()) > 3:
                        #                 incorpAddr = k
                        kTest = k.split()
                        if len(kTest) > 2:
                            incorpAddr = ' '.join(kTest[-2:]).replace('of', '').replace('corporation', '').replace('incorporated',
                                                                                                 '').strip()
                        else:
                            incorpAddr = k.strip()

                        # break
                        break
            else:
                incorpAddr = None
        else:
            incorpAddr = None
        ii = 1 if len(split_result) != 1 else 0

        addr = re.sub('\([^\)]\)', '', split_result[ii])
        final_addr = addr.split(',')[-1]
        final_addr = [re.sub('inclu.*', '', k[0]) for k in re.findall(',([a-z\. ]+)([0-9]*)', addr) if
                      len(k[0].strip()) > 1]
        if final_addr:
            final_addr = final_addr[-1].strip()
        else:
            final_addr = None
        # if final_addr:

        #             final_addr = final_addr[-1]
        #             final_addr_test = [k for k in final_addr.split() if len(k)>1]
        #             if len(final_addr_test) > 1:
        #                 len(final_addr_test[-1]) <= 3
        #                 final_addr = final_addr_test[-1]
        #             else:
        #                 final_addr = ' '.join(final_addr_test)

        return {'Status': False, 'Incorporation': incorpAddr, 'Domicile': final_addr}
    except Exception as e:
        print(e)
        return {'Status': False, 'Incorporation': None, 'Domicile': None}



def inc_add_in_table_s3(content):
    # print(content)
    # content = ' '.join(content)

    content = re.sub('\( ', '(', content.text)
    content = content.replace('\n', ' ')

    content = re.sub('\d\d or \d\d', ' ', content)
    content = re.sub(r'[^\x00-\x7F]', ' ', content).lower()
    content = re.sub(' +', ' ', content)
    keyword = re.search(
        '\(address[a-z0-9 ,\']+\)|address of principal executive office|\(principal[a-z0-9 ,\']+\)|\(former.*address.* last report\)|including area code|telephone:',
        content)

    pattern = '\(address[a-z0-9 ,\']+\)|address of principal executive offices|address of principal executive office|\(principal[a-z0-9 ,\']+\)|\(former.*address.* last report\)|including area code|telephone:'.split(
        '|')
    testContent = ['a'] * 200
    for pa in pattern:

        testContent = re.split(pa, content, maxsplit=1)
        if len(testContent) == 2:
            break

    content = testContent[0]
    # print(content)
    if len(content) > 1500:
        return {'rawContent': None, 'finalAddress': None, 'newdate': None, 'country': None, 'keyword': None,
                'filteredAddress': None}
    # content = content[0]
    # print(content)
    if keyword:
        keyword = keyword.group(0)

    # print('result = ',content)

    rawContent = content
    finalData = ExtractIncAndDom(rawContent)
    return finalData

    #
# headers = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36"}
# resp = requests.get('https://www.sec.gov/Archives/edgar/data/1800/000104746918000856/a2234264z10-k.htm', headers=headers).content
# jsoup = BeautifulSoup(resp)
# for k in jsoup.find_all('div', attrs={'style':'display:none'}):
#     k.decompose()
#
# content = jsoup.text
# result = ExtractIncAndDom(content)
# print(result)