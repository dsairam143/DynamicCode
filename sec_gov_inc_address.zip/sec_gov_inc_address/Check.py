import requests
from bs4 import BeautifulSoup


def SecondChec(name):

    remove = [' INC', ' CORP', ' ORD', ' LTD']
    combination = []
    combination.append(name)
    for rem in remove:
        if rem in name:
            combination.append(name.split(rem)[0])
    print(combination)
    data = {"companyName": None, "table": None,"url":None}
    for combi in combination:
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36"}
        url = 'https://www.sec.gov/cgi-bin/browse-edgar?company='+combi.replace('&', '%26').replace(' ', '+')+'&owner=exclude&action=getcompany'
        resp = requests.get('https://www.sec.gov/cgi-bin/browse-edgar?company='+combi.replace('&', '%26').replace(' ', '+')+'&owner=exclude&action=getcompany', headers=headers).content
        jsoup = BeautifulSoup(resp)
        companyName = jsoup.find('span', attrs={'class':'companyName'})
        table = jsoup.find('div', attrs={'id':'seriesDiv'})

        if table and not companyName:
            print('table and not companyName')
            CKI = None
            dummy = []
            for tr in table.find_all('tr'):
                td = tr.find_all('td')
                if td:
                    print(td[0].text, td[1].text.replace('SIC:', ' SIC:'))
                    dummy.append([td[0].text, td[1].text.replace('SIC:', ' SIC:')])
            for comb in combination:
                found = False

                for k in dummy:
                    print(comb.strip().lower() + ' ', '=====', k[1].strip().lower())
                    if comb.strip().lower()+' ' in k[1].strip().lower():
                        CKI = k
                        found = True
                        break
                if found:
                    break
            print('FOund = ', CKI)
            if CKI:
                url = 'https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK='+str(CKI[0])+'&owner=exclude&count=40&hidefilings=0'
                resp = requests.get(url)

                jsoup = BeautifulSoup(resp.content)
                companyName = jsoup.find('span', attrs={'class': 'companyName'})

                table = jsoup.find('div', attrs={'id': 'seriesDiv'})
                companyName = companyName.text if companyName else companyName
                data =  {"companyName":companyName, "table":table, "url":url}

            else:
                data = {"companyName": None, "table": None}
        elif table and companyName:
            companyName = jsoup.find('span', attrs={'class': 'companyName'})
            companyName = companyName.text if companyName else companyName
            data =  {"companyName":companyName, "table":table, "url":url}
        else:
            data = {"companyName": None, "table": None, "url":url}
        if data['companyName']:
            break
    return data
# result = SecondChec('CHEVRON CORP')
# print(result['companyName'])