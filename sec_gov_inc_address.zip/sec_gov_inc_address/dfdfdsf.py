import re
x = """

Suite 103 Wyomissing PA 19610 (Address of principal executive offices, including zip code)


"""


def test2(x):
    if not isinstance(x, str):
        return None
    x = x.replace('\n', ' ')
    x = re.sub('\([^\)]*\)', ' ', x)
    addr = re.sub('\([^\)]\)', '', x).strip()
    addr = re.sub(r'[^\x00-\x7F]', ' ', addr)
    print(addr)
    final_addr = addr.split(',')[-1]
    print(final_addr)
    a = re.search(',([a-z\. ]+)([0-9]+)', addr, re.IGNORECASE)
    if ',' in addr:
        return re.sub('[0-9]+','', addr.split(',')[-1]).strip()
    elif a:
        a = a.group(1)
        return a.strip()
    elif re.findall('([a-z\. ]+)([0-9]+)', addr, re.IGNORECASE):

        print(re.findall('[a-z]+ \d{4,}', addr, re.IGNORECASE))

        return re.sub('[0-9]+', '',re.findall('[a-z]+ \d{4,}', addr, re.IGNORECASE)[-1])
    else:
        return None
d = test2(x)
print(d)