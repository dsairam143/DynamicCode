import requests
from bs4 import BeautifulSoup
import dateutil.parser as dparser
import re
from geotext import GeoText
from datetime import datetime
from Scenario1 import inc_add_in_table_s1
from Scenario2 import inc_add_in_table_s2
from Scenario3 import inc_add_in_table_s3
today = datetime.today().year

def extractDateAndAddress(content, jsoup):
    # print(content)
    # content = ' '.join(content)

    content = re.sub('\( ', '(', content)
    content = content.replace('\n', ' ')

    content = re.sub('\d\d or \d\d', ' ', content)
    content = re.sub(r'[^\x00-\x7F]', ' ', content).lower()
    content = re.sub(' +', ' ', content)
    keyword = re.search('\(address[a-z0-9 ,\']+\)|address of principal executive office|\(principal[a-z0-9 ,\']+\)|\(former.*address.* last report\)|including area code|telephone:', content)

    pattern = '\(address[a-z0-9 ,\']+\)|address of principal executive offices|address of principal executive office|\(principal[a-z0-9 ,\']+\)|\(former.*address.* last report\)|including area code|telephone:'.split('|')
    testContent = ['a']*200
    for pa in pattern:

        testContent = re.split(pa,content, maxsplit=1)
        if len(testContent)==2:
            break


    content = testContent[0]
    # print(content)
    if len(content) >1500:
        return {'rawContent':None, 'finalAddress':None, 'newdate':None, 'country':None, 'keyword':None, 'filteredAddress':None, 'incorporation':None, 'domicile':None}
    # content = content[0]
    # print(content)
    if keyword:
        keyword = keyword.group(0)

    # print('result = ',content)
    newdate = re.search('[a-zA-Z\.]* \d?\d, \d{4}|\d{4}[-\.]\d\d[-\.]\d\d|\d\d?[-\/.]\d\d?[-\/.]\d{4}|[a-zA-Z]* \d\d?, [a-zA-Z]* \d{4}|\d\d? [a-zA-Z]*  ?\d{4}',content)
    newdate = newdate.group(0) if newdate else newdate

    # print(newdate)
    if newdate:
        newdate = dparser.parse(newdate, fuzzy=True).date().strftime('%m-%d-%Y')
    else:
        try:
            year = ['jan', 'feb', 'mar', 'april', 'may', 'june', 'july', 'aug', 'sep', 'oct', 'nov', 'dec']
            for k in year:
                try:
                    testContent = content[content.lower().index(k)-len(k):]
                    testContent = testContent[:25]
                    newdate = dparser.parse(testContent, fuzzy=True).strftime('%m-%d-%Y')
                    break
                except:
                    pass
        except Exception as e:
            print(e)
            newdate = None
    try:
        s1 = inc_add_in_table_s1(jsoup)
    except:
        s1 = {'Status': False, 'Incorporation': None, 'Domicile': None}
    incorporation = s1['Incorporation']
    domicile = s1['Domicile']
    try:
        s2 = inc_add_in_table_s2(jsoup)
    except:
        s2 = {'Status': False, 'Incorporation': None, 'Domicile': None}
    if not incorporation:
        incorporation = s2['Incorporation']
    if not domicile:
        domicile = s2['Domicile']
    try:
        s3 = inc_add_in_table_s3(jsoup)
    except:
        s3 = {'Status': False, 'Incorporation': None, 'Domicile': None}
    if not incorporation:
        incorporation = s3['Incorporation']
    if not domicile:
        domicile = s3['Domicile']

    rawContent = content

    finalAddress = content

    Address = re.findall(r'[a-z0-9.\-, ]+', content)

    filteredAddress = ''
    if Address:
        for k in Address[::-1]:
            if len(k)>10:

                filteredAddress = k.strip().strip('-').strip()
                break
    country = [k for k in GeoText(filteredAddress.title()).country_mentions.keys()]


    return {'rawContent':rawContent, 'finalAddress':finalAddress, 'newdate':newdate, 'country':country, 'keyword':keyword, 'filteredAddress':filteredAddress, 'incorporation':incorporation, 'domicile':domicile}

# #
# headers = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36"}
# resp = requests.get('https://www.sec.gov/Archives/edgar/data/1599489/000110465918066185/a18-39562_18k.htm', headers=headers).content
# jsoup = BeautifulSoup(resp)
# for k in jsoup.find_all('div', attrs={'style':'display:none'}):
#     k.decompose()
#
# content = jsoup.text
# result = extractDateAndAddress(content, jsoup)
# print(result)