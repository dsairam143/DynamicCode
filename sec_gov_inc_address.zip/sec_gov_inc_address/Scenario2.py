import requests
import re
from bs4 import BeautifulSoup


#check incorporation and address:
def tableDataExtractor(table):
    # if jsoup.find('table'):
    #     print('found')
    # table = jsoup.find('table')

    trs = table.find_all('tr')
    nooftd = 0
    for tr in trs:
        tds = tr.find_all(re.compile('th|td'))
        if len(tds) > nooftd:
            nooftd = len(tds)
    trList = []
    for tr in trs:
        tds = tr.find_all(re.compile('th|td'))
        tdList = []
        for td in tds:
            colspan = 0
            try:
                colspan = int(td['colspan'])
            except:
                pass
            if colspan != 0:
                tdList.append(td.text)
                for k in range(colspan - 1):
                    tdList.append('')
            else:
                # link = td.find('a')['href'] if td.find('a') else None
                tdList.append(td.text)

        trList.append(tdList)
    return trList
def filterContent(fcontent):
    fcontent = fcontent.replace('\n', ' ')
    fcontent = re.sub('\d\d or \d\d', ' ', fcontent)
    fcontent = re.sub(r'[^\x00-\x7F]', ' ', fcontent).lower()
    fcontent = re.sub(' +', ' ', fcontent)
    return fcontent
def inc_add_in_table_s2(jsoup):
    addressData = {'Status':False, 'Incorporation':None, 'Domicile':None}

    #if incorporation found in table the below code will be execute.
    table = jsoup.find('table')
    content = table.text.lower()
    content = content.replace('\n', ' ')
    content = re.sub('\d\d or \d\d', ' ', content)
    content = re.sub(r'[^\x00-\x7F]', ' ', content).lower()
    content = re.sub(' +', ' ', content)
    # print(table)
    pattern = '\(address[a-z0-9 ,\']+\)|address of principal executive offices|address of principal executive office|\(principal[a-z0-9 ,\']+\)|\(former.*address.* last report\)|including area code|telephone:'

    incorporationAddress = False
    patten2 = '\(state .+incorporation[^\(]*\)|state of incorporation|jurisdiction'
    for pa in patten2.split():
        if re.search(pa, content):
            incorporationAddress =True
            break
    if incorporationAddress:
        # print(table)
        tableData = tableDataExtractor(table)
        for id, ta in enumerate(tableData):
            for subId, k in enumerate(ta):
                # print('======================================')
                k = k.lower()
                k = k.replace('\n', ' ')
                k = re.sub('\d\d or \d\d', ' ', k)
                k = re.sub(r'[^\x00-\x7F]', ' ', k).lower()
                k = re.sub(' +', ' ', k)
                for kp in pattern.split('|'):
                    if re.search(kp, k.strip()):
                        print('Address Found')
                        if not addressData['Domicile']:
                            Domicile = tableData[id-1][subId]

                            addressData['Domicile'] = Domicile
                            break
                for kp in patten2.split('|'):
                    if re.search(kp, k):
                        if not addressData['Incorporation']:
                            Incorporation = tableData[id-1][subId]
                            addressData['Incorporation'] = Incorporation
                            break


    # if address found in p tags the below code will be execute.
    content = filterContent(jsoup.text.lower())
    print('content = ',content)
    tableAddress = False
    for pa in pattern.split('|'):
        if re.search(pa, content):
            tableAddress =True
            break

    if tableAddress:
        pList = jsoup.find_all('p', attrs={'align':'center'})
        if not pList:
            pList = jsoup.find_all('font')
        print(pList)
        for ptd, p in enumerate(pList):
            text = filterContent(p.text)
            print(text)
            if '@' in text:
                del pList[ptd]
                continue
            textFound = False
            for pa in pattern.split('|'):
                if re.search(pa, text):
                    textFound = True
                    break
            if textFound:
                Domicile = ' '.join([kk.text for kk in pList[ptd-2:ptd+1]])
                addressData['Domicile'] = Domicile
                break

    # if address found in p tags the below code will be execute.
    content = filterContent(jsoup.text.lower())
    print('content = ', content)
    inAddress = False
    for pa in patten2.split('|'):
        if re.search(pa, content):
            inAddress = True
            break

    if inAddress:
        pList = jsoup.find_all('p', attrs={'align': 'center'})

        for ptd, p in enumerate(pList):
            text = filterContent(p.text)
            print(text)
            if '@' in text:
                del pList[ptd]
                continue
            textFound = False
            for pa in patten2.split('|'):
                if re.search(pa, text):
                    textFound = True
                    break
            if textFound:
                Incorporation = ' '.join([kk.text for kk in pList[ptd - 1:ptd]])
                addressData['Incorporation'] = Incorporation
                break
    return addressData

# resp = requests.get('https://www.sec.gov/Archives/edgar/data/1101239/000162828018002212/eqix_20171231x10k.htm').content
# jsoup = BeautifulSoup(resp)
# print(inc_add_in_table_s2(jsoup))