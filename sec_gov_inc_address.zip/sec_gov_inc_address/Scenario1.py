import requests
import re
from bs4 import BeautifulSoup

#check incorporation and address:
def tableDataExtractor(table):
    trs = table.find_all('tr')
    nooftd = 0
    for tr in trs:
        tds = tr.find_all(re.compile('th|td'))
        if len(tds) > nooftd:
            nooftd = len(tds)
    trList = []
    for tr in trs:
        tds = tr.find_all(re.compile('th|td'))
        tdList = []
        for td in tds:
            colspan = 0
            try:
                colspan = int(td['colspan'])
            except:
                pass
            if colspan != 0:
                tdList.append(td.text)
                for k in range(colspan - 1):
                    tdList.append('')
            else:
                # link = td.find('a')['href'] if td.find('a') else None
                tdList.append(td.text)

        trList.append(tdList)
    return trList

def inc_add_in_table_s1(jsoup):
    addressData = {'Status': False, 'Incorporation': None, 'Domicile': None}
    count = 0
    count_2 = 0
    for table in jsoup.find_all('table'):

        print(table)
        # table = jsoup.find('table')
        content = table.text.lower()
        content = content.replace('\n', ' ')
        content = re.sub('\d\d or \d\d', ' ', content)
        content = re.sub(r'[^\x00-\x7F]', ' ', content).lower()
        content = re.sub(' +', ' ', content)
        # print(table)
        pattern = '\(address[a-z0-9 ,\']+\)|\(address[a-z0-9 ,\']+|address of principal executive offices|address of principal executive office|\(principal[a-z0-9 ,\']+\)|\(former.*address.* last report\)|including area code|telephone:'

        tableAddress = False
        incorporationAddress = False
        for pa in pattern.split('|'):
            if re.search(pa, content):
                tableAddress =True
                break
        patten2 = '\(state .+incorporation[^\(]*\)|state of incorporation|jurisdiction'
        for pa in patten2.split():
            if re.search(pa, content):
                incorporationAddress =True
                break
        if incorporationAddress or tableAddress:
            # print(table)
            tableData = tableDataExtractor(table)
            for id, ta in enumerate(tableData):
                for subId, k in enumerate(ta):
                    # print('======================================')
                    k = k.lower()
                    k = k.replace('\n', ' ')
                    k = re.sub('\d\d or \d\d', ' ', k)
                    k = re.sub(r'[^\x00-\x7F]', ' ', k).lower()
                    k = re.sub(' +', ' ', k)
                    for kp in pattern.split('|'):
                        if re.search(kp, k.strip()):
                            print('Address Found')
                            if not addressData['Domicile']:
                                Domicile = tableData[id-1][subId]

                                addressData['Domicile'] = Domicile.strip() if len(Domicile.strip())>=1 else None

                                break
                    for kp in patten2.split('|'):
                        if re.search(kp, k):
                            if not addressData['Incorporation']:
                                Incorporation = tableData[id-1][subId]
                                addressData['Incorporation'] = Incorporation
                                count = 1
                                break
        if addressData['Incorporation'] and addressData['Domicile']:
            break

        if count == 1:
            count_2+=1
        if count_2 == 5:
            break
    return addressData


# resp = requests.get('https://www.sec.gov/Archives/edgar/data/1101239/000162828018002212/eqix_20171231x10k.htm').content
# jsoup = BeautifulSoup(resp)
#
# result = inc_add_in_table_s1(jsoup)
# print(result)